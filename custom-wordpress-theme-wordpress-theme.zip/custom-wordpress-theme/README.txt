Custom WordPress Theme

Converted from an HTML/CSS/JS template.
Install: WordPress Admin > Appearance > Themes > Add New > Upload Theme.

Note: complex template interactions, forms, sliders, AJAX, PHP backends, and page-builder features may require manual conversion.
