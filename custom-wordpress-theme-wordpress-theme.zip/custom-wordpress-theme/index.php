<?php get_header(); ?>

<header class="header">
<div class="container nav-wrap">
<a class="logo" href="#home">Dhruv<span>.</span></a>
<nav class="nav" id="nav">
<a href="#home">Home</a><a href="#about">About</a><a href="#skills">Skills</a>
<a href="#qualification">Qualification</a><a href="#services">Services</a>
<a href="#portfolio">Portfolio</a><a href="#contact">Contact</a>
</nav>
<div class="nav-actions">
<span class="clock" id="clock"></span>
<button aria-label="Toggle dark mode" class="icon-btn" id="themeBtn">☾</button>
<button aria-label="Toggle menu" class="icon-btn menu-btn" id="menuBtn">☰</button>
</div>
</div>
</header>
<main>
<section class="section hero container grid-2" id="home">
<div>
<div class="availability"><i></i> Available for work</div>
<p class="muted small">Hi, I am</p>
<h1>Dhruv</h1><h2>Frontend Developer</h2>
<p class="lead">I build responsive websites and web applications with React, Tailwind CSS and modern frontend tools.</p>
<div class="actions"><a class="btn primary" href="#contact">Contact Me ↗</a><a class="btn secondary" href="#portfolio">View Work</a></div>
<div class="social"><a href="https://www.linkedin.com/" target="_blank">in</a><a href="https://github.com/" target="_blank">gh</a><a href="mailto:hello@dhruv.dev">✉</a></div>
</div>
<div class="hero-art"><div class="blob blob-outer"><div class="blob blob-inner"><div class="person"><div class="head"></div></div></div></div></div>
</section>
<section class="section" id="about">
<div class="container grid-2">
<div class="photo-card"><div class="photo-placeholder"><div class="person simple"></div></div></div>
<div>
<p class="eyebrow">My introduction</p><h2 class="section-title">About Me</h2>
<p class="body-text">Web developer focused on responsive interfaces, reusable React components, APIs and UI/UX. I like building products that are simple to understand and reliable to use.</p>
<div class="stats"><div><b>2+</b><span>Years experience</span></div><div><b>20+</b><span>Completed projects</span></div><div><b>5+</b><span>Technologies</span></div></div>
<a class="btn primary" href="#contact">Download CV ↓</a>
</div>
</div>
</section>
<section class="section" id="skills">
<div class="container">
<div class="center"><p class="eyebrow">My technical level</p><h2 class="section-title">Skills</h2></div>
<div class="skills-list" id="skillsList"></div>
</div>
</section>
<section class="section qualification" id="qualification">
<div class="container">
<div class="center"><p class="eyebrow">My personal journey</p><h2 class="section-title">Qualification</h2></div>
<div class="tabs"><button class="tab active" data-tab="education">🎓 Education</button><button class="tab" data-tab="work">💼 Work</button></div>
<div class="qualification-list" id="qualificationList"></div>
</div>
</section>
<section class="section" id="services">
<div class="container">
<div class="center"><p class="eyebrow">What I offer</p><h2 class="section-title">Services</h2></div>
<div class="cards-3" id="servicesList"></div>
</div>
</section>
<section class="section" id="portfolio">
<div class="container">
<div class="center"><p class="eyebrow">My recent work</p><h2 class="section-title">Portfolio</h2></div>
<div class="filters"><button class="filter active" data-filter="All">All</button><button class="filter" data-filter="Web App">Web App</button><button class="filter" data-filter="Website">Website</button></div>
<div class="cards-3" id="portfolioList"></div>
</div>
</section>
<section class="section process" id="process">
<div class="container">
<div class="center"><p class="eyebrow">How I work</p><h2 class="section-title">Step-by-step process</h2></div>
<div class="process-grid"></div>
</div>
</section>
<section class="section" id="contact">
<div class="container">
<div class="center"><p class="eyebrow">Get in touch</p><h2 class="section-title">Contact Me</h2></div>
<div class="contact-grid">
<div class="contact-links">
<a class="contact-card" href="mailto:hello@dhruv.dev"><b>✉ Email</b><span>hello@dhruv.dev</span></a>
<a class="contact-card" href="https://www.linkedin.com/" target="_blank"><b>in LinkedIn</b><span>Connect with me</span></a>
<a class="contact-card" href="https://github.com/" target="_blank"><b>⌘ GitHub</b><span>View my code</span></a>
</div>
<form class="form" id="contactForm">
<input placeholder="Name" required=""/><input placeholder="Email" required="" type="email"/>
<textarea placeholder="Project / message" required="" rows="5"></textarea>
<button class="btn primary full">Send message ↗</button>
</form>
</div>
</div>
</section>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?><?php the_content(); ?><?php endwhile; endif; ?></main>
<footer>
<div class="footer-logo">Dhruv<span>.</span></div>
<p>Frontend Developer • React • Tailwind CSS • Vite</p>
<div class="footer-links"><a href="https://github.com/" target="_blank">GitHub</a><a href="https://www.linkedin.com/" target="_blank">LinkedIn</a><a href="mailto:hello@dhruv.dev">Email</a></div>
<small>© <span id="year"></span> Dhruv. All rights reserved.</small>
</footer>
<div class="modal hidden" id="modal">
<div class="modal-box"><button class="modal-close" id="modalClose">×</button><h3 id="modalTitle"></h3><p id="modalText"></p><a class="btn primary" href="#contact" id="modalProject">Start a project</a></div>
</div>
<script src="&lt;?php echo esc_url(get_template_directory_uri() . '/script.js'); ?&gt;"></script>

<?php get_footer(); ?>