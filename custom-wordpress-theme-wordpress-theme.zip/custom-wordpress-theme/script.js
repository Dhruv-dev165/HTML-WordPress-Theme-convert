const skills=[["HTML",90],["CSS",85],["JavaScript",80],["React",88],["Tailwind CSS",90],["REST APIs",75]];
const qualification={education:[["Frontend Development","React, JavaScript & responsive web","2023 — Present"],["Modern Web Development","Vite, Tailwind CSS & APIs","2024 — Present"]],work:[["Creative Developer","Independent projects","2024 — Present"],["Customer Experience","D-Mart","Previous"]]};
const services=[["◫","UI / UX Design","I design clean interfaces and practical user flows for modern web products."],["⌘","Frontend Development","Responsive React websites with reusable components and real interactions."],["✦","Brand & Web","Landing pages and portfolio experiences that present your work clearly."]];
const projects=[{title:"Flight Tracker",type:"Web App",description:"Live global flight dashboard with search, status and responsive data cards.",tags:["React","API","Tailwind"]},{title:"Portfolio Studio",type:"Website",description:"Responsive personal portfolio with theme switching and polished interactions.",tags:["Vite","React","SEO"]},{title:"Virtual Phone",type:"Web App",description:"Interactive browser device interface with app-style navigation.",tags:["React","UI","CSS"]}];

const $=s=>document.querySelector(s);
function renderSkills(){ $("#skillsList").innerHTML=skills.map(([n,p],i)=>`<div class="skill"><div class="skill-head" data-skill="${i}"><span><span class="skill-name">${n}</span><span class="skill-pct">${p}%</span></span><span class="eyebrow" id="arrow-${i}">⌄</span></div><div class="progress"><span style="width:${p}%"></span></div><p class="skill-desc" id="skill-desc-${i}" hidden>Practical experience with ${n} for responsive, production-ready web interfaces.</p></div>`).join("");
 document.querySelectorAll("[data-skill]").forEach(el=>el.onclick=()=>{const i=el.dataset.skill;const d=$("#skill-desc-"+i);d.hidden=!d.hidden;$("#arrow-"+i).textContent=d.hidden?"⌄":"⌃"});
}
function renderQualification(tab="education"){ $("#qualificationList").innerHTML=qualification[tab].map(([t,s,d])=>`<div class="qual-card"><h3>${t}</h3><p>${s}</p><p class="date">${d}</p></div>`).join("");document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));}
function renderServices(){ $("#servicesList").innerHTML=services.map(([icon,t,d])=>`<div class="service"><div class="service-icon">${icon}</div><h3>${t}</h3><p>${d}</p><button class="more" data-service="${t}" data-desc="${d.replaceAll('"','&quot;')}">View more →</button></div>`).join("");document.querySelectorAll("[data-service]").forEach(b=>b.onclick=()=>openModal(b.dataset.service,b.dataset.desc));}
function renderPortfolio(filter="All"){const list=filter==="All"?projects:projects.filter(p=>p.type===filter);$("#portfolioList").innerHTML=list.map(p=>`<article class="portfolio-card"><div class="portfolio-image">${p.title}</div><div class="portfolio-info"><h3>${p.title}</h3><p>${p.description}</p><div class="tags">${p.tags.map(t=>`<span class="tag">${t}</span>`).join("")}</div></div></article>`).join("");document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===filter));}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>renderQualification(b.dataset.tab));
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>renderPortfolio(b.dataset.filter));
function openModal(title,text){$("#modalTitle").textContent=title;$("#modalText").textContent=text;$("#modal").classList.remove("hidden")}
$("#modalClose").onclick=()=>$("#modal").classList.add("hidden");
$("#modal").onclick=e=>{if(e.target.id==="modal")$("#modal").classList.add("hidden")};
$("#modalProject").onclick=()=>$("#modal").classList.add("hidden");
$("#menuBtn").onclick=()=>{$("#nav").classList.toggle("open");$("#menuBtn").textContent=$("#nav").classList.contains("open")?"×":"☰"};
$("#themeBtn").onclick=()=>{document.body.classList.toggle("dark");$("#themeBtn").textContent=document.body.classList.contains("dark")?"☀":"☾";localStorage.setItem("dhruv-theme",document.body.classList.contains("dark")?"dark":"light")};
if(localStorage.getItem("dhruv-theme")==="dark"){document.body.classList.add("dark");$("#themeBtn").textContent="☀"}
function tick(){$("#clock").textContent=new Date().toLocaleTimeString()} tick();setInterval(tick,1000);$("#year").textContent=new Date().getFullYear();
$("#contactForm").onsubmit=e=>{e.preventDefault();alert("Thanks! Connect this form to your backend or email service to receive submissions.");e.target.reset()};
renderSkills();renderQualification();renderServices();renderPortfolio();
document.querySelectorAll(".nav a").forEach(a=>a.onclick=()=>$("#nav").classList.remove("open"));
