<?php
function custom_wordpress_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    register_nav_menus(array('primary' => __('Primary Menu', 'custom-wordpress-theme')));
}
add_action('after_setup_theme', 'custom_wordpress_theme_setup');

function custom_wordpress_theme_assets() {
    wp_enqueue_style('theme-style', get_stylesheet_uri(), array(), '1.0.0');
}
add_action('wp_enqueue_scripts', 'custom_wordpress_theme_assets');
